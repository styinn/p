<?php
include 'koneksi.php';

$result = mysqli_query($koneksi, "SELECT * FROM buku");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Buku</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Data Buku</h1>
    <a href="tambah_buku.php">Tambah Buku</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Judul</th>
            <th>Penulis</th>
            <th>Penerbit</th>
            <th>Jenis</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id_buku']; ?></td>
            <td><?php echo $row['judul']; ?></td>
            <td><?php echo $row['penulis']; ?></td>
            <td><?php echo $row['penerbit']; ?></td>
            <td><?php echo $row['jenis']; ?></td>
            <td><?php echo $row['stok']; ?></td>
            <td>
                <a href="edit_buku.php?id=<?php echo $row['id_buku']; ?>">Edit</a>
                <a href="hapus_buku.php?id=<?php echo $row['id_buku']; ?>" onclick="return confirm('Apakah anda yakin?')">Hapus</a>
                <?php if ($row['stok'] > 0): ?>
                <a href="tambah_transaksi.php?status=peminjaman&id_buku=<?php echo $row['id_buku']; ?>">Pinjam</a>
                <?php else: ?>
                <span>Tidak bisa dipinjam</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
