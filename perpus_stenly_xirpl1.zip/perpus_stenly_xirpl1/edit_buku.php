<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = mysqli_query($koneksi, "SELECT * FROM buku WHERE id_buku=$id");
    $row = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id_buku'];
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $jenis = $_POST['jenis'];
    $stok = $_POST['stok'];

    $query = "UPDATE buku SET judul='$judul', penulis='$penulis', penerbit='$penerbit', jenis='$jenis', stok='$stok' WHERE id_buku=$id";
    mysqli_query($koneksi, $query);
    header('Location: data_buku.php');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Buku</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Edit Buku</h1>
    <form method="POST" action="">
        <input type="hidden" name="id_buku" value="<?php echo $row['id_buku']; ?>">
        <label>Judul:</label><br>
        <input type="text" name="judul" value="<?php echo $row['judul']; ?>" required><br>
        <label>Penulis:</label><br>
        <input type="text" name="penulis" value="<?php echo $row['penulis']; ?>" required><br>
        <label>Penerbit:</label><br>
        <input type="text" name="penerbit" value="<?php echo $row['penerbit']; ?>" required><br>
        <label>Jenis:</label><br>
        <input type="text" name="jenis" value="<?php echo $row['jenis']; ?>" required><br>
        <label>Stok:</label><br>
        <input type="number" name="stok" value="<?php echo $row['stok']; ?>" required><br><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
