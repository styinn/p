<?php
include 'koneksi.php';

$status = $_GET['status'];

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE id_transaksi=$id");
    $row = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_transaksi = $_POST['id_transaksi'];
    $id_buku = $_POST['id_buku'];
    $jumlah = $_POST['jumlah'];
    $peminjam = $_POST['peminjam'];
    $telepon = $_POST['telepon'];
    $tanggal = $_POST['tanggal'];

    $query = "UPDATE transaksi SET id_buku='$id_buku', jumlah='$jumlah', peminjam='$peminjam', telepon='$telepon', status='$status', tanggal='$tanggal' WHERE id_transaksi=$id_transaksi";
    mysqli_query($koneksi, $query);
    if ($status == 'peminjaman') {
        header('Location: peminjaman.php');
    } elseif ($status == 'pengembalian') {
        header('Location: pengembalian.php');
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit <?php echo ucfirst($status); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Edit <?php echo ucfirst($status); ?></h1>
    <form method="POST" action="">
        <input type="hidden" name="id_transaksi" value="<?php echo $row['id_transaksi']; ?>">
        <label>ID Buku:</label><br>
        <input type="text" name="id_buku" value="<?php echo $row['id_buku']; ?>" required><br>
        <label>Jumlah:</label><br>
        <input type="number" name="jumlah" value="<?php echo $row['jumlah']; ?>" required><br>
        <label>Peminjam:</label><br>
        <input type="text" name="peminjam" value="<?php echo $row['peminjam']; ?>" required><br>
        <label>Telepon:</label><br>
        <input type="text" name="telepon" value="<?php echo $row['telepon']; ?>" required><br>
        <label>Tanggal:</label><br>
        <input type="date" name="tanggal" value="<?php echo $row['tanggal']; ?>" required><br><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
