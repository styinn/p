<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE FROM buku WHERE id_buku=$id");
    header('Location: data_buku.php');
}
?>
