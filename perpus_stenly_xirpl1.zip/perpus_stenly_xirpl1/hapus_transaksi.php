<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE FROM transaksi WHERE id_transaksi=$id");
    if ($_GET['status'] == 'peminjaman') {
        header('Location: peminjaman.php');
    } elseif ($_GET['status'] == 'pengembalian') {
        header('Location: pengembalian.php');
    }
}
?>
