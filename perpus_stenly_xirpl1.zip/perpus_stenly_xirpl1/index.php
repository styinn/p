<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Perpustakaan</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Dashboard Perpustakaan</h1>
    <nav>
        <a href="data_buku.php">Data Buku</a>
        <a href="peminjaman.php">Transaksi Peminjaman</a>
        <a href="pengembalian.php">Transaksi Pengembalian</a>
    </nav>
</body>
</html>
