<?php
include 'koneksi.php';

$result = mysqli_query($koneksi, "SELECT transaksi.*, buku.judul FROM transaksi JOIN buku ON transaksi.id_buku = buku.id_buku WHERE status='pengembalian'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi Pengembalian</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Transaksi Pengembalian</h1>
    <a href="tambah_transaksi.php?status=pengembalian">Tambah Pengembalian</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Judul Buku</th>
            <th>Jumlah</th>
            <th>Peminjam</th>
            <th>Telepon</th>
            <th>Status</th>
            <th>Tanggal</th>
            <th>Aksi</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id_transaksi']; ?></td>
            <td><?php echo $row['judul']; ?></td>
            <td><?php echo $row['jumlah']; ?></td>
            <td><?php echo $row['peminjam']; ?></td>
            <td><?php echo $row['telepon']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['tanggal']; ?></td>
            <td>
                <a href="edit_transaksi.php?id=<?php echo $row['id_transaksi']; ?>&status=pengembalian">Edit</a>
                <a href="hapus_transaksi.php?id=<?php echo $row['id_transaksi']; ?>" onclick="return confirm('Apakah anda yakin?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
