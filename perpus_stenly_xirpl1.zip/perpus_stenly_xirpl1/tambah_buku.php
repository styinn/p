<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $jenis = $_POST['jenis'];
    $stok = $_POST['stok'];

    $query = "INSERT INTO buku (judul, penulis, penerbit, jenis, stok) VALUES ('$judul', '$penulis', '$penerbit', '$jenis', '$stok')";
    mysqli_query($koneksi, $query);
    header('Location: data_buku.php');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Buku</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Tambah Buku</h1>
    <form method="POST" action="">
        <label>Judul:</label><br>
        <input type="text" name="judul" required><br>
        <label>Penulis:</label><br>
        <input type="text" name="penulis" required><br>
        <label>Penerbit:</label><br>
        <input type="text" name="penerbit" required><br>
        <label>Jenis:</label><br>
        <input type="text" name="jenis" required><br>
        <label>Stok:</label><br>
        <input type="number" name="stok" required><br><br>
        <button type="submit">Tambah</button>
    </form>
</body>
</html>
