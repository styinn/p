<?php
include 'koneksi.php';

$status = $_GET['status'] ?? 'peminjaman';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_buku = $_POST['id_buku'];
    $jumlah = $_POST['jumlah'];
    $peminjam = $_POST['peminjam'];
    $telepon = $_POST['telepon'];
    $tanggal = $_POST['tanggal'];

    if ($status == 'peminjaman') {
        $query_check = "SELECT stok FROM buku WHERE id_buku='$id_buku'";
        $result_check = mysqli_query($koneksi, $query_check);
        $row_check = mysqli_fetch_assoc($result_check);
        if ($row_check['stok'] >= $jumlah) {
            $query_update = "UPDATE buku SET stok = stok - '$jumlah' WHERE id_buku='$id_buku'";
            mysqli_query($koneksi, $query_update);
            $query = "INSERT INTO transaksi (id_buku, jumlah, peminjam, telepon, status, tanggal) VALUES ('$id_buku', '$jumlah', '$peminjam', '$telepon', '$status', '$tanggal')";
            mysqli_query($koneksi, $query);
            header('Location: peminjaman.php');
        } else {
            echo "Stok buku tidak cukup!";
        }
    } elseif ($status == 'pengembalian') {
        $query_update = "UPDATE buku SET stok = stok + '$jumlah' WHERE id_buku='$id_buku'";
        mysqli_query($koneksi, $query_update);
        $query = "INSERT INTO transaksi (id_buku, jumlah, peminjam, telepon, status, tanggal) VALUES ('$id_buku', '$jumlah', '$peminjam', '$telepon', '$status', '$tanggal')";
        mysqli_query($koneksi, $query);
        header('Location: pengembalian.php');
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Transaksi</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Tambah <?php echo ucfirst($status); ?></h1>
    <form method="POST" action="">
        <label>ID Buku:</label><br>
        <input type="text" name="id_buku" required><br>
        <label>Jumlah:</label><br>
        <input type="number" name="jumlah" required><br>
        <label>Peminjam:</label><br>
        <input type="text" name="peminjam" required><br>
        <label>Telepon:</label><br>
        <input type="text" name="telepon" required><br>
        <label>Tanggal:</label><br>
        <input type="date" name="tanggal" required><br><br>
        <button type="submit">Tambah</button>
    </form>
</body>
</html>
